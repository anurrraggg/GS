import Component from "../ground-station"

export default function Page() {
  return <Component />
}
